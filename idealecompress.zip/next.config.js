/** @type {import('next').NextConfig} */
const nextConfig = {
  unoptimized: true,
};

module.exports = nextConfig;
